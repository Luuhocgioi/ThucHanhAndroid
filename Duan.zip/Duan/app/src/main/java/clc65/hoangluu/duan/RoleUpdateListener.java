package clc65.hoangluu.duan;

public interface RoleUpdateListener {
    void onRoleUpdated(String newRole);
}